<?php $__env->startSection('title', 'Laravel - SI Perpustakaan'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="jumbotron">
            <h1 class="display-4">Selamat Datang!</h1>
            <p class="lead">Ini adalah contoh sistem informasi perpustakaan sederhana</p>
            <hr class="my-4">            
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Gabungan\resources\views\index.blade.php ENDPATH**/ ?>
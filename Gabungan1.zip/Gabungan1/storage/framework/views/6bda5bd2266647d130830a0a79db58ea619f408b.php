<?php $__env->startSection('title', 'Laravel - SI penjualan online'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="jumbotron">

            <?php
                $jenis = ['samsung', 'xiaomi', 'iphone', 'Nokia', "SEMUA"];
            ?>
                    
                

                <?php if($msg = Session::get('msg')): ?>
                    <div class="alert alert-success">
                        <span><?php echo e($msg); ?></span>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>   
                    </div>
                <?php endif; ?>


            <h1 class="display-6">Data Barang</h1>
            <hr class="my-2">     

            <a href="<?php echo e(route('barang.create')); ?>" class="btn btn-primary mb-1 my-3">Tambah Barang</a>

            <form action="<?php echo e(route('barang.index')); ?>" class="row mb-4">
                    <div class="col-md-8">
                        <select name="jenis" class="form-control">
                            <option value="" disabled selected>Pilih Jenis Hp</option>
                            <?php $__currentLoopData = $jenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jns): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($jns == "SEMUA" ? "" : $jns); ?>" ><?php echo e($jns); ?> </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        </select>
                    </div>
                    <input type="submit" class="btn btn-success float-right mb-4" value="Cari">

            <table class="table">
                <thead class="thead-dark">
                    <tr>
                
                    <th scope="col">ID</th>
                    <th scope="col">Jenis Barang</th>
                    <th scope="col">Type Barang</th>
                    <th scope="col">Jumlah Barang</th>
                    <th scope="col">Action</th>
                    <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $dataBarang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($brg['id']); ?></td>
                        <td><?php echo e($brg['jenis']); ?></td>
                        <td><?php echo e($brg['type']); ?></td>
                        <td><?php echo e($brg['jumlah']); ?></td>
                        <td>
                            <form action="<?php echo e(route('barang.destroy',$brg['id'])); ?>" method="POST">
                            <a href="<?php echo e(route('barang.show',$brg['id'])); ?>" class="badge badge-primary">Detail</a>
                            <a href="<?php echo e(route('barang.edit',$brg['id'])); ?>" class="badge badge-primary">Edit</a>
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('DELETE')); ?>

                            <button type="submit" class="badge badge-danger" onclick="return confirm('Yakin ingin menghapus data?')">Hapus</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <td colspan="3"> Tidak ada Data</td>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <script>
        function action(){  
            var jenis = document.getElementById('jenis').value;
            window.location = "<?php echo e(url('barang')); ?>/"+jenis;
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Gabungan\resources\views/Data_Barang/data-barang.blade.php ENDPATH**/ ?>
@extends('main')

@section('title', 'Laravel - Toko HP')

@section('content')
    <div class="container">
        <div class="jumbotron">
            <h1 class="display-4">Selamat Datang!</h1>
            <p class="lead">Toko Hp Kita!!</p>
            <hr class="my-4">            
        </div>
    </div>
@endsection